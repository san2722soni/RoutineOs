export { default } from "@/src/features/settings/SettingsScreen";
